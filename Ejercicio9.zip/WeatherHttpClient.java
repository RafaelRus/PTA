import java.lang.StringBuffer;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.net.URLConnection;

public class WeatherHttpClient {
	private static String BASE_URL = "http://api.openweathermap.org/data/2.5/weather?q=";
	private static String IMG_URL = "http://openweathermap.org/img/w/";
	private static String APPID = "9278328b09cce4937d0cab4a493dcb86";
	
	public String getWeatherData(String location) {
  		HttpURLConnection con = null ;
  		InputStream is = null;	
  		try {
   			con = (HttpURLConnection)(new URL(BASE_URL + location + "&APPID=" + APPID)).openConnection();
   			con.setRequestMethod("GET");
   			con.setDoInput(true);
   			con.setDoOutput(true);
   			con.connect();
   			StringBuffer buffer = new StringBuffer();
   			is = con.getInputStream();
   			BufferedReader br = new BufferedReader(new InputStreamReader(is));
   			String line = null;
   			while((line = br.readLine()) != null) {
     				buffer.append(line + "rn");
			}
   			is.close();
   			con.disconnect();
   			return buffer.toString();
 		} catch(Exception e) {
  			e.printStackTrace();
 		} finally {
  			try {
				is.close();
			} catch(Exception e) {}
  			try {
				con.disconnect();
			} catch(Exception e) {}
 		} 
 		return null;
	}
 
	public byte[] getImage(String code) {
  		HttpURLConnection con = null;
  		InputStream is = null;
  		try {
   			con = (HttpURLConnection)(new URL(IMG_URL + code)).openConnection();
   			con.setRequestMethod("GET");
   			con.setDoInput(true);
   			con.setDoOutput(true);
   			con.connect();
 	 		is = con.getInputStream();
  			byte[] buffer = new byte[1024];
  			ByteArrayOutputStream baos = new ByteArrayOutputStream();
 			while(is.read(buffer) != -1) {
				baos.write(buffer);
   				return baos.toByteArray();
  			} catch(Exception e) {
   				e.printStackTrace();
  			} finally {
   				try {
					is.close();
				} catch(Exception e) {}
   				try {
					con.disconnect();
				} catch(Exception e) {}
  			}
  			return null;
 		}
	}
}